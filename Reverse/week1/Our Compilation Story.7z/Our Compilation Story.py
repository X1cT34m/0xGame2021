from flag import flag
o0o="qwq"
O0O=len(flag)
for oOo in range(O0O):
    oOo=chr(ord(o0o[oOo])^ord(flag[oOo]))
    o0o=o0o+oOo
o0o=o0o[::-1]
O0O=len(o0o)-1
for oOo in range(O0O):
    print(ord(o0o[oOo]),end=",")
print(ord(o0o[O0O]))
#21,44,45,104,31,30,26,121,65,125,23,112,77,46,47,126,89,112,7,109,7,88,10,105,104,59,54,91,83,98,32,54,15,65,113,119,113
