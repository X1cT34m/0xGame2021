from math import log
from secret import flag
def f(x):
    return x*log(x) #log(x) is "ln(x)" used in maths

for i in flag:
    print(f(ord(i)))
