from Crypto.Util.number import *

f = open('flag.txt', 'rb')
m = bytes_to_long(f.read())
f.close()
e = 65537
p = getPrime(1024)
q = getPrime(1024)
n = p * q
c = pow(m, e, n)
hint1 = pow(2021 * p + q, 20212021, n)
hint2 = pow(1010 * p + 1011, q, n)
f = open('message.txt', 'w')
f.write(f'n={n}\n')
f.write(f'c={c}\n')
f.write(f'hint1={hint1}\n')
f.write(f'hint2={hint2}\n')
f.close()
